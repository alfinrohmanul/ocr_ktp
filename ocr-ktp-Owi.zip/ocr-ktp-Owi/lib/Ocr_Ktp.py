#library
from imutils import contours
import numpy as np
import argparse
import imutils
import pytesseract
import cv2
import csv 
import os
from PIL import Image
from ocr.helpers import implt, resize, ratio

#OCR KTP
class Ocr_Ktp(object):
    def ocr(self,file):
        PATH = os.path.expanduser('./static')
        hasil_ocr = ''
 
    
        #crop image ktp full to isi dari ktp
        def crop0(image):
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            th, threshed = cv2.threshold(gray, 127, 255, cv2.THRESH_TRUNC)
            y=155
            x=10
            h=900
            w=1850
            hasil_c1 = threshed[y:y+h, x:x+w]
            return hasil_c1
        #resize image bagian isi ktp
        def resize0(hasil_c1):
            hasil_resize0 = cv2.resize(hasil_c1,(1700,1000))
            return hasil_resize0

        #crop image bagian NIK
        def cropNIK(hasil_resize0):
            y=25
            x=375
            h=100
            w=800
            cropnik = hasil_resize0[y:y+h, x:x+w]
            return cropnik

        #crop image bagian inti
        def cropINTI(hasil_resize0):
            y=135
            x=420
            h=800
            w=730
            cropinti = hasil_resize0[y:y+h, x:x+w]
            return cropinti

        #image to string
        def ImageToString(imagrCrop):
            text = pytesseract.image_to_string(imagrCrop)
            return text

        def TextProcessing(hasil_text):
            text = hasil_text
            # text = hasil_text.replace("/ ","\n")
            text = text.replace(", ","\n")
            text = text.replace(" Gol. Darah: -","")
            text = text.replace(" Gol. Darah : -","")
            text = text.replace(" Gol. Darah : O","")
            text = text.replace(" Gol. Darah : A","")
            text = text.replace(" Gol. Darah : B","")
            text = text.replace(" Gol. Darah : AB","")
            text = text.replace("\n\n","\n")
            text = text.lstrip()
            return text   
        #OCR
        def ocrjadi(image):
            hasil_c1 = crop0(image)
            hasil_resize0 = resize0(hasil_c1)
            hasil_cropNIK = cropNIK(hasil_resize0)
            hasil_cropINTI = cropINTI(hasil_resize0)
            textNIK = ImageToString(hasil_cropNIK)
            textINTI = ImageToString(hasil_cropINTI)
            
            hasil_text = textNIK+ os.linesep + textINTI
            hasil_text1 = TextProcessing(hasil_text)
            with open(PATH + '/file/'+'hasilocr.txt', mode ='w',encoding="utf-8") as file:
                file.write(hasil_text1)
            return hasil_text1

       
        # with open("xtosOoGvc.jpg", "rb") as image_file:
        #     image = image_file.read()
        image = cv2.imread(file)

        hasil_ocr =  ocrjadi(image)
        return (hasil_ocr)