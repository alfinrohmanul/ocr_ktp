from flask import Flask, flash, request, jsonify, render_template, redirect, url_for, jsonify
import os
import pymysql
from random import *
from werkzeug.utils import secure_filename
import string
import hmac
import hashlib
from flask_mysqldb import MySQL
from lib.Ocr_Ktp import Ocr_Ktp as Ocr_Ktp
import datetime
import time
from PIL import Image
from io import BytesIO
from base64 import decodestring
from PIL import Image
from io import BytesIO
import base64
import binascii
from functools import wraps


APP_URL = "http://localhost:5000/"
UPLOAD_FOLDER = './static/image/'
PATH = os.path.expanduser('./static')

# Load Ocr_ktp library
Ocr_Ktp = Ocr_Ktp()

app = Flask(__name__)
app.secret_key = 'secret key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# connect to database
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '12345678'
app.config['MYSQL_DB'] = 'ocr_ktp'
mysql = MySQL(app)

# fungsi for random filename


def random_string(text):
    min_char = 9
    max_char = 15
    allchar = string.ascii_letters + string.digits
    string1 = "".join(choice(allchar)
                      for x in range(randint(min_char, max_char)))
    return(string1)


def token():
    apikey = 'gmm*2020$!'
    secret = 'bG2w6EXvmSUS866'+str(int(time.time()))[0:8]
    return hmac.new(apikey.encode('utf-8'), secret.encode('utf-8'), hashlib.sha256).hexdigest()


def authenticate(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        headers = request.headers
        auth = headers.get("X-Api-Key")
        if auth != token():
            return jsonify({"message": "ERROR: Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated_function


class OCR_Ktp():
    @app.route('/')
    @authenticate
    def hello():
        return jsonify(
            App="OCR KTP v1.0"+str(time.time())
        )

    @app.route('/api/upload', methods=['GET', 'POST'])
    @authenticate
    def ocr_ktp():
        Current_Date = datetime.datetime.today().strftime("%Y-%m-%d-%H.%M.%S")
        if request.method == 'POST':
            data = request.get_json(force=True)
            cek = data.get('image')
            # get value jason base64
            file = request.get_json('image')
            with open(PATH + '/file/'+'base64_text.txt', 'w+') as f:
                f.write(str(file))
            with open(PATH + '/file/'+'base64_text.txt', 'r') as f:
                hasil = f.read()
            if cek != "":
               # base64 to image
                file = hasil
                starter = file.find(',')
                image_data = file[starter+1:]
                image_data = bytes(image_data, encoding="ascii")
                # cek apakah base64 rusak atau tidak
                try:
                    im = Image.open(BytesIO(base64.b64decode(image_data)))

                    # rename filename
                    Current_Date = datetime.datetime.today().strftime("%Y-%m-%d-%H.%M.%S")
                    new_filename = random_string(Current_Date)

                    # save image
                    filepath = os.path.join(
                        app.config['UPLOAD_FOLDER'], new_filename + '.jpg')
                    im.save(filepath)

                    # image to string (OCR)
                    Ocr_Ktp.ocr(filepath)

                    # string to json
                    hasil_akhir = []
                    with open(PATH + '/file/'+'hasilocr.txt', 'r') as f:
                        hasil = f.readlines()
                    # cek apakah data sudah sesuai dengan ktp, kalau tidak hanya keluar nomor ktp
                    if len(hasil) == 14:
                        for index, str_ in enumerate(hasil):
                            hasil[index] = str_.replace('\n', '')
                        hasil_akhir.append({
                            "nik": hasil[0],
                            "nama": hasil[1],
                            "Tempat lahir": hasil[2],
                            "Tgl lahir": hasil[3],
                            "Genre": hasil[4],
                            "Alamat": hasil[5],
                            "Rt/Rw": hasil[6],
                            "Desa": hasil[7],
                            "Kec": hasil[8],
                            "Agama": hasil[9],
                            "Status": hasil[10],
                            "Pekerjaan": hasil[11],
                            "Kewarganegaraan": hasil[12],
                            "Tgl Berlaku": hasil[13],
                        })
                        # log database sukses
                        sql = "INSERT INTO log(result,status,created_at) VALUES(%s,%s,%s)"
                        data = (hasil_akhir, "succes", Current_Date)
                        cur = mysql.connection.cursor()
                        cur.execute(sql, data)
                        mysql.connection.commit()
                        # hasilsemua dari json
                        result = {}
                        result['image'] = APP_URL + \
                            "static/image/" + new_filename+'.jpg'
                        result['data'] = hasil_akhir
                        result['status'] = "200"
                        return jsonify(result)
                    else:
                        # mneampilkan kesalahan ktp
                        result = {}
                        nik = hasil[0].replace('\n', '')
                        result['image'] = APP_URL + \
                            "static/image/" + new_filename+'.jpg'
                        result['data'] = nik
                        result['status'] = "terjadi kerusahan KTP pada bagian data"

                        # log error
                        sql = "INSERT INTO log(result,status,created_at) VALUES(%s,%s,%s)"
                        data = (nik, "Error", Current_Date)
                        cur = mysql.connection.cursor()
                        cur.execute(sql, data)
                        mysql.connection.commit()

                        return jsonify(result)

                except binascii.Error:

                    result = {}
                    result['message'] = "base64 error atau rusak "
                    result['status'] = "fail"

                    # log error
                    sql = "INSERT INTO log(failure_log,status,created_at) VALUES(%s,%s,%s)"
                    data = ("base64 error atau rusak", "Error", Current_Date)
                    cur = mysql.connection.cursor()
                    cur.execute(sql, data)
                    mysql.connection.commit()
                    return jsonify(result)

            else:
                result = {}
                result['message'] = "Base64 Null"
                result['status'] = "fail"

                # log error
                sql = "INSERT INTO log(failure_log,status,created_at) VALUES(%s,%s,%s)"
                data = ("Base64 Null", "Error", Current_Date)
                cur = mysql.connection.cursor()
                cur.execute(sql, data)
                mysql.connection.commit()
                return jsonify(result)

        else:
            result = {}
            result['message'] = "Method Post not allowed"
            result['status'] = "fail"

            # log error
            sql = "INSERT INTO log(failure_log,status,created_at) VALUES(%s,%s,%s)"
            data = ("Method Post not allowed", "Error", Current_Date)
            cur = mysql.connection.cursor()
            cur.execute(sql, data)
            mysql.connection.commit()
            return jsonify(result)


if __name__ == '__main__':
    app.run()
