berisi file
