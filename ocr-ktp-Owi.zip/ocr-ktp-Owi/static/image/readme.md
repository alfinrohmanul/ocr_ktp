berisi image
