Requirement

- Python 3
- Anaconda
- pyTesseract
- OpenCV
- Flask
- NumPy
- Pandas
